function agregarMeta() {
  const input = document.getElementById("metaInput");
  const lista = document.getElementById("listaMetas");

  if (input.value !== "") {
    const item = document.createElement("li");
    item.textContent = input.value;

    item.onclick = function () {
      item.style.textDecoration = "line-through";
    };

    lista.appendChild(item);
    input.value = "";
  }
}
